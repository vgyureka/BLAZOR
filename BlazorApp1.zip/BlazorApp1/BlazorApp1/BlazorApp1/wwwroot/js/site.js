﻿function saveMessage(firstname, lastname) {
    alert(firstname + ' ' + lastname + " has been saved succesfully !!");
}
function getCities() {
    var cities = ['delhi', 'punjab', 'up', 'mp'];
    return cities;

}